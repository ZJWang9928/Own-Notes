package com.validate.Action;

import com.opensymphony.xwork2.ActionSupport;
import com.validate.Model.RegUser;

import java.util.regex.Pattern;

public class RegAndLoginAction extends ActionSupport {
    private RegUser user;

    @Override
    public void validate() {
        System.out.println("validate method");
    }

    public void validateReg() {
        String username = user.getUsername();
        String password = user.getPassword();
        String password2 = user.getPassword2();

        if (username == null || username.isEmpty())
            this.addFieldError("user.username", "用户名不为空");
        else if (!Pattern.matches("^[a-zA-Z][a-zA-Z0-9_]{3,14}$", username))
            this.addFieldError("user.username", "用户名只能是字母开头，后面可以跟数字、字母、下划线，且长度为4-15位");
        else if (password == null || password.isEmpty())
            this.addFieldError("user.password", "密码不为空");
        else if (!password.equals(password2))
            this.addFieldError("user.password2", "两次输入密码不一致,请重新输入");
        else if (user.getAge() < 16)
            this.addFieldError("user.age", "未满16岁，不能注册");
    }

    public RegUser getUser() {
        return user;
    }

    public String reg() {
        System.out.println("login success!");
        return "success";
    }

    public void setUser(RegUser user) {
        this.user = user;
    }
}
