
// _________________________________________________________________
//
//                            GuiStart.h
//              Startup Code for Win32 GUI Applications
//                   01-20-1997 Sven B. Schreiber
//                           sbs@orgon.com
// _________________________________________________________________



// =================================================================
// STARTUP CODE
// =================================================================

void WinStartup ()
    {
    STARTUPINFO StartupInfo;
    PSTR        psCmdLine;
    int         iCmdShow;
    char        cQuote;

    psCmdLine = GetCommandLine ();
    while (*psCmdLine++ == ' ');
    cQuote = (*--psCmdLine == '"' ? *psCmdLine++ : ' ');
    while (*psCmdLine && (*psCmdLine++ != cQuote));
    while (*psCmdLine++ == ' ');
    psCmdLine--;

    GetStartupInfo (&StartupInfo);
    iCmdShow = (StartupInfo.dwFlags & STARTF_USESHOWWINDOW ?
                (int) StartupInfo.wShowWindow :
                SW_SHOWDEFAULT);

    ExitProcess (WinMain (GetModuleHandle (NULL),
                          NULL,
                          psCmdLine,
                          iCmdShow));
    }

// =================================================================
// END OF FILE
// =================================================================
