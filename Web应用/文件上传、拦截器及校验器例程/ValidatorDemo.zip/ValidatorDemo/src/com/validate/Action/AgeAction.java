package com.validate.Action;

import com.opensymphony.xwork2.ActionSupport;

import java.util.HashMap;
import java.util.Map;

public class AgeAction extends ActionSupport {
    private Map<Integer, String> ageMap;

    public AgeAction() {
        ageMap = new HashMap<Integer, String>();
        for (int i = 1; i <= 120; i++) {
            ageMap.put(i, i + "");
        }
    }

    public Map<Integer, String> getAgeMap() {
        return ageMap;
    }

    public void setAgeMap(Map<Integer, String> ageMap) {
        this.ageMap = ageMap;
    }
}
